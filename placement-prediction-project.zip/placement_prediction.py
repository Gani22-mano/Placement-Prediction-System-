import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

data = pd.read_csv("data/placement_data.csv")

X = data[["CGPA","Internships","CodingScore","CommunicationScore"]]
y = data["Placed"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

predictions = model.predict(X_test)

print("Accuracy:", accuracy_score(y_test, predictions))

student = [[8.9, 2, 84, 80]]
result = model.predict(student)[0]

if result == 1:
    print("Prediction: Likely to be Placed")
else:
    print("Prediction: Not Likely to be Placed")
