# Placement Prediction System

## Objective
Predict whether a student is likely to get placed based on:
- CGPA
- Number of Internships
- Coding Score
- Communication Score

## Technologies Used
- Python
- Pandas
- Scikit-Learn
- Machine Learning

## Algorithm
Random Forest Classifier

## How to Run

```bash
pip install -r requirements.txt
python placement_prediction.py
```

## Resume Description
Developed a Machine Learning-based Placement Prediction System that analyzes academic and skill-based parameters to predict student placement outcomes. Implemented data preprocessing, model training, and performance evaluation using Python and Scikit-Learn.
